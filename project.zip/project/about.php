<?php

include 'components/connect.php';

if(isset($_COOKIE['user_id'])){
   $user_id = $_COOKIE['user_id'];
}else{
   $user_id = '';
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>about</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>

<?php include 'components/user_header.php'; ?>

<!-- about section starts  -->

<section class="about">

   <div class="row">

      <div class="image">
         <img src="images/about1.jpg" alt="">
      </div>

      <div class="content">
         <h3>ولې موږ غوره کړئ؟</h3>
         <p>موږ تاسو ته دا متخصصو استادانو لخوا ترتیب شوی درسونه او نور روزنیز توکې په هر وخت او هر ځائ کې نړیوالو معیارونو سره سم وړاندې کوو</p>
         <a href="courses.html" class="inline-btn">زموږ کورسونه</a>
      </div>

   </div>

   <div class="box-container">

      <div class="box">
         <i class="fas fa-graduation-cap"></i>
         <div>
            <h3>+1k</h3>
            <span>په لیکه کورسونه</span>
         </div>
      </div>

      <div class="box">
         <i class="fas fa-user-graduate"></i>
         <div>
            <h3>+25k</h3>
            <span>ځیرک زده کونکې</span>
         </div>
      </div>

      <div class="box">
         <i class="fas fa-chalkboard-user"></i>
         <div>
            <h3>+5k</h3>
            <span>ماهر استادان</span>
         </div>
      </div>

      <div class="box">
         <i class="fas fa-briefcase"></i>
         <div>
            <h3>100%</h3>
            <span>کار موندنې مرسته</span>
         </div>
      </div>

   </div>

</section>

<!-- about section ends -->

<!-- reviews section starts  -->

<section class="reviews">

   <h1 class="heading">زده کونکو نظرونه</h1>

   <div class="box-container">

      <div class="box">
         <p> اوسني وخت کې، آنلاین زده کړه د تعلیم یوه مؤثره طریقه ګرځیدلې. زموږ هدف د یوه داسې ویب سایټ جوړول دی چې کاروونکو ته د کیفیتي او متنوع زده کړو موادو ته لاسرسی ورکړي</p>
         <div class="user">
            <img src="images/student1.jpg" alt="">
            <div>
               <h3>احمد</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star-half-alt"></i>
               </div>
            </div>
         </div>
      </div>

      <div class="box">
         <p> اوسني وخت کې، آنلاین زده کړه د تعلیم یوه مؤثره طریقه ګرځیدلې. زموږ هدف د یوه داسې ویب سایټ جوړول دی چې کاروونکو ته د کیفیتي او متنوع زده کړو موادو ته لاسرسی ورکړي؟</p>
         <div class="user">
            <img src="images/student2.jpg" alt="">
            <div>
               <h3>محمود</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star-half-alt"></i>
               </div>
            </div>
         </div>
      </div>

      <div class="box">
         <p> اوسني وخت کې، آنلاین زده کړه د تعلیم یوه مؤثره طریقه ګرځیدلې. زموږ هدف د یوه داسې ویب سایټ جوړول دی چې کاروونکو ته د کیفیتي او متنوع زده کړو موادو ته لاسرسی ورکړي?</p>
         <div class="user">
            <img src="images/student3.jpg" alt="">
            <div>
               <h3>جاوید</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star-half-alt"></i>
               </div>
            </div>
         </div>
      </div>

      <div class="box">
         <p> اوسني وخت کې، آنلاین زده کړه د تعلیم یوه مؤثره طریقه ګرځیدلې. زموږ هدف د یوه داسې ویب سایټ جوړول دی چې کاروونکو ته د کیفیتي او متنوع زده کړو موادو ته لاسرسی ورکړي؟</p>
         <div class="user">
            <img src="images/student4.jpg" alt="">
            <div>
               <h3>جلال</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star-half-alt"></i>
               </div>
            </div>
         </div>
      </div>

      <div class="box">
         <p> اوسني وخت کې، آنلاین زده کړه د تعلیم یوه مؤثره طریقه ګرځیدلې. زموږ هدف د یوه داسې ویب سایټ جوړول دی چې کاروونکو ته د کیفیتي او متنوع زده کړو موادو ته لاسرسی ورکړي؟</p>
         <div class="user">
            <img src="images/student5.jpg" alt="">
            <div>
               <h3>بدرالدین</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star-half-alt"></i>
               </div>
            </div>
         </div>
      </div>

      <div class="box">
         <p> اوسني وخت کې، آنلاین زده کړه د تعلیم یوه مؤثره طریقه ګرځیدلې. زموږ هدف د یوه داسې ویب سایټ جوړول دی چې کاروونکو ته د کیفیتي او متنوع زده کړو موادو ته لاسرسی ورکړي؟</p>
         <div class="user">
            <img src="images/student6.jpg" alt="">
            <div>
               <h3>اکرام</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star-half-alt"></i>
               </div>
            </div>
         </div>
      </div>

   </div>

</section>

<!-- reviews section ends -->










<?php include 'components/footer.php'; ?>

<!-- custom js file link  -->
<script src="js/script.js"></script>
   
</body>
</html>