<footer class="footer">

   &copy; copyright @ <?= date('Y'); ?> by <span>mr. fazalhaq and abdulaziz</span> | all rights reserved!

</footer>